package project4backendservice.backendservice.controller;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;
import project4backendservice.backendservice.model.LogEntry;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    private static final String MONGO_URI = "mongodb+srv://abelwadi:eg87g3edb122@mydbcluster.xqjeg28.mongodb.net/?retryWrites=true&w=majority&appName=MyDBCluster";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<LogEntry> logs = new ArrayList<>();

        try (MongoClient client = MongoClients.create(MONGO_URI)) {
            MongoDatabase db = client.getDatabase("myDB");
            MongoCollection<Document> collection = db.getCollection("logs");
            FindIterable<Document> docs = collection.find();

            for (Document d : docs) {
                LogEntry entry = new LogEntry(
                        d.getString("event"),
                        d.getLong("timestamp"),
                        d.getString("source"),
                        d.getList("request_params", String.class),
                        d.getString("model"),
                        d.getString("os")
                );
                logs.add(entry);
            }
        }

        req.setAttribute("logs", logs);
        req.getRequestDispatcher("index.jsp").forward(req, resp);
    }
}
