package project4backendservice.backendservice.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import project4backendservice.backendservice.service.GitaService;
import project4backendservice.backendservice.util.MongoLogger;

import java.io.IOException;

@WebServlet(name = "GitaServlet", urlPatterns = {"/api/*"})
public class GitaServlet extends HttpServlet {
    private final GitaService gitaService = new GitaService();
    private final MongoLogger logger = new MongoLogger();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String path = req.getPathInfo();
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        String model = req.getHeader("X-Device-Model");
        String os = req.getHeader("X-Device-OS");


        if (path == null || path.equals("/chapters")) {
            String json = gitaService.getChapters();
            logger.log("get_chapters", null, model = model, os = os);
            resp.getWriter().write(json);

        } else if (path.matches("/chapters/\\d+")) {
            int chapterId = Integer.parseInt(path.split("/")[2]);
            String json = gitaService.getChapterDetails(chapterId);
            logger.log("get_chapter_details", new String[]{"chapter_id=" + chapterId}, model = model, os = os);
            resp.getWriter().write(json);

        } else if (path.matches("/chapters/\\d+/verses")) {
            int chapterId = Integer.parseInt(path.split("/")[2]);
            String json = gitaService.getChapterVerses(chapterId);
            logger.log("get_verse_list", new String[]{"chapter_id=" + chapterId}, model = model, os = os);
            resp.getWriter().write(json);

        } else if (path.matches("/chapters/\\d+/verses/\\d+")) {
            int chapterId = Integer.parseInt(path.split("/")[2]);
            int verseId = Integer.parseInt(path.split("/")[4]);
            String json = gitaService.getVerseDetails(chapterId, verseId);
            logger.log("get_verse_details", new String[]{
                    "chapter_id=" + chapterId, "verse_id=" + verseId
            }, model = model, os = os);
            resp.getWriter().write(json);

        } else {
            resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
            resp.getWriter().write("{\"error\":\"Invalid endpoint\"}");
        }
    }
}

