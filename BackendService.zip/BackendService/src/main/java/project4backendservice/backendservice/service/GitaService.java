package project4backendservice.backendservice.service;

import org.json.JSONArray;
import org.json.JSONObject;
import project4backendservice.backendservice.model.Chapter;
import project4backendservice.backendservice.model.Verse;

import java.io.IOException;
import java.net.URI;
import java.net.http.*;
import java.util.ArrayList;
import java.util.List;

public class GitaService {
    private static final String API_BASE = "https://bhagavad-gita3.p.rapidapi.com/v2";
    private static final String API_KEY = "8b9696c5e4msh8c7276d6565937bp185ea0jsn12d248362bc1";
    private static final String HOST = "bhagavad-gita3.p.rapidapi.com";
    private final HttpClient client = HttpClient.newHttpClient();

    private String fetch(String endpoint) {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(API_BASE + endpoint))
                .header("x-rapidapi-key", API_KEY)
                .header("x-rapidapi-host", HOST)
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            return response.body();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getChapters() {
        String raw = fetch("/chapters/?skip=0&limit=18");
        if (raw == null) return "{\"error\": \"Unable to fetch chapters\"}";

        JSONArray jsonChapters = new JSONArray(raw);
        List<Chapter> chapters = new ArrayList<>();

        for (int i = 0; i < jsonChapters.length(); i++) {
            JSONObject c = jsonChapters.getJSONObject(i);
            chapters.add(new Chapter(
                    c.getInt("chapter_number"),
                    c.getString("name"),
                    c.getString("name_meaning"),
                    c.getInt("verses_count")
            ));
        }

        JSONArray result = new JSONArray();
        for (Chapter ch : chapters) {
            JSONObject o = new JSONObject();
            o.put("chapter_number", ch.getChapter_number());
            o.put("name", ch.getName());
            o.put("meaning", ch.getName_meaning());
            o.put("verses_count", ch.getVerses_count());
            result.put(o);
        }

        return new JSONObject().put("chapters", result).toString();
    }

    public String getChapterDetails(int chapterId) {
        String raw = fetch("/chapters/" + chapterId + "/");
        if (raw == null) return "{\"error\": \"Unable to fetch chapter detail\"}";

        JSONObject c = new JSONObject(raw);
        Chapter ch = new Chapter(
                c.getInt("chapter_number"),
                c.getString("name"),
                c.getString("name_meaning"),
                c.getInt("verses_count")
        );
        ch.setChapter_summary(c.getString("chapter_summary"));

        JSONObject o = new JSONObject();
        o.put("chapter_number", ch.getChapter_number());
        o.put("name", ch.getName());
        o.put("meaning", ch.getName_meaning());
        o.put("verses_count", ch.getVerses_count());
        o.put("summary", ch.getChapter_summary());

        return o.toString();
    }

    public String getChapterVerses(int chapterId) {
        String raw = fetch("/chapters/" + chapterId + "/verses/");
        if (raw == null) return "{\"error\": \"Unable to fetch verses\"}";

        JSONArray jsonVerses = new JSONArray(raw);
        JSONArray result = new JSONArray();

        for (int i = 0; i < jsonVerses.length(); i++) {
            JSONObject v = jsonVerses.getJSONObject(i);
            JSONObject o = new JSONObject();
            o.put("verse_number", v.getInt("verse_number"));
            o.put("slug", v.getString("slug"));
            result.put(o);
        }

        return new JSONObject().put("verses", result).toString();
    }

    public String getVerseDetails(int chapterId, int verseId) {
        String raw = fetch("/chapters/" + chapterId + "/verses/" + verseId + "/");
        if (raw == null) return "{\"error\": \"Unable to fetch verse detail\"}";

        Verse verse = getVerse(raw);

        JSONObject o = new JSONObject();
        o.put("verse_number", verse.getVerse_number());
        o.put("text", verse.getText());
        o.put("transliteration", verse.getTransliteration());
        o.put("translation", verse.getTranslation());

        return o.toString();
    }

    private static Verse getVerse(String raw) {
        JSONObject v = new JSONObject(raw);
        Verse verse = new Verse(
                v.getInt("verse_number"),
                v.getString("text"),
                v.getString("transliteration")
        );

        JSONArray translations = v.getJSONArray("translations");
        JSONObject firstTranslation = translations.length() > 0 ? translations.getJSONObject(0) : null;
        if (firstTranslation != null) {
            verse.setTranslation(firstTranslation.getString("description"));
        }
        return verse;
    }
}
