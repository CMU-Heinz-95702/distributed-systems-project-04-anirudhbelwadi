package project4backendservice.backendservice.util;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.Arrays;

public class MongoLogger {
    private final MongoClient mongoClient;
    private final MongoDatabase database;

    public MongoLogger() {
        String uri = "mongodb+srv://abelwadi:eg87g3edb122@mydbcluster.xqjeg28.mongodb.net/?retryWrites=true&w=majority&appName=MyDBCluster";
        ServerApi api = ServerApi.builder().version(ServerApiVersion.V1).build();
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(uri))
                .serverApi(api)
                .build();

        mongoClient = MongoClients.create(settings);
        database = mongoClient.getDatabase("myDB");
    }

    public void log(String event, String[] params, String model, String os) {
        Document doc = new Document("event", event)
                .append("timestamp", System.currentTimeMillis())
                .append("source", "android_app")
                .append("model", model)
                .append("os", os);

        if (params != null)
            doc.append("request_params", Arrays.asList(params));

        database.getCollection("logs").insertOne(doc);
    }
}
