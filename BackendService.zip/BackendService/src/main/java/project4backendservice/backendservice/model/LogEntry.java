package project4backendservice.backendservice.model;

import java.util.List;

public class LogEntry {
    private String event;
    private long timestamp;
    private String source;
    private List<String> request_params;

    private String device_model;
    private String device_os;


    public LogEntry(String event, long timestamp, String source, List<String> request_params, String device_model, String device_os) {
        this.event = event;
        this.timestamp = timestamp;
        this.source = source;
        this.request_params = request_params;
        this.device_model = device_model;
        this.device_os = device_os;
    }

    // Getters
    public String getEvent() { return event; }
    public long getTimestamp() { return timestamp; }
    public String getSource() { return source; }
    public List<String> getRequest_params() { return request_params; }
    public String getDevice_model() { return device_model; }
    public String getDevice_os() { return device_os; }

    // Setters
    public void setEvent(String event) { this.event = event; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public void setSource(String source) { this.source = source; }
    public void setRequest_params(List<String> request_params) { this.request_params = request_params; }
    public void setDevice_model(String device_model) { this.device_model = device_model; }
    public void setDevice_os(String device_os) { this.device_os = device_os; }
}
