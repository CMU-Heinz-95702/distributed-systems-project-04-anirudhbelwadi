package project4backendservice.backendservice.model;

public class Chapter {
    private int chapter_number;
    private String name;
    private String name_meaning;
    private int verses_count;
    private String chapter_summary; // Optional (used in detail only)

    // Constructor (for list endpoint)
    public Chapter(int chapter_number, String name, String name_meaning, int verses_count) {
        this.chapter_number = chapter_number;
        this.name = name;
        this.name_meaning = name_meaning;
        this.verses_count = verses_count;
    }

    // Getters
    public int getChapter_number() { return chapter_number; }
    public String getName() { return name; }
    public String getName_meaning() { return name_meaning; }
    public int getVerses_count() { return verses_count; }
    public String getChapter_summary() { return chapter_summary; }

    // Setters
    public void setChapter_number(int chapter_number) { this.chapter_number = chapter_number; }
    public void setName(String name) { this.name = name; }
    public void setName_meaning(String name_meaning) { this.name_meaning = name_meaning; }
    public void setVerses_count(int verses_count) { this.verses_count = verses_count; }
    public void setChapter_summary(String chapter_summary) { this.chapter_summary = chapter_summary; }
}
