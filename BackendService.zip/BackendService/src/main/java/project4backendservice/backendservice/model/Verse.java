package project4backendservice.backendservice.model;

public class Verse {
    private int verse_number;
    private String text;
    private String transliteration;
    private String translation;

    public Verse(int verse_number, String text, String transliteration) {
        this.verse_number = verse_number;
        this.text = text;
        this.transliteration = transliteration;
    }

    // Getters
    public int getVerse_number() { return verse_number; }
    public String getText() { return text; }
    public String getTransliteration() { return transliteration; }
    public String getTranslation() { return translation; }

    // Setters
    public void setVerse_number(int verse_number) { this.verse_number = verse_number; }
    public void setText(String text) { this.text = text; }
    public void setTransliteration(String transliteration) { this.transliteration = transliteration; }
    public void setTranslation(String translation) { this.translation = translation; }
}
