package com.example.bhagavadgita.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import com.example.bhagavadgita.R;
import com.example.bhagavadgita.network.ApiClient;
import com.example.bhagavadgita.network.ApiService;
import com.google.gson.JsonObject;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VerseDetailActivity extends AppCompatActivity {
    private TextView tvText, tvTransliteration, tvTranslation;
    private int chapterId, verseNumber;

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verse_detail);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        tvText = findViewById(R.id.tvText);
        tvTransliteration = findViewById(R.id.tvTransliteration);
        tvTranslation = findViewById(R.id.tvTranslation);

        chapterId = getIntent().getIntExtra("chapter_number", -1);
        verseNumber = getIntent().getIntExtra("verse_number", -1);

        if (chapterId == -1 || verseNumber == -1) {
            Toast.makeText(this, "Invalid verse details", Toast.LENGTH_SHORT).show();
            finish();
        }

        fetchVerseDetail();
    }

    private void fetchVerseDetail() {
        ApiService api = ApiClient.getApiService();
        api.getVerseDetails(chapterId, verseNumber).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful() && response.body() != null) {
                    JsonObject verse = response.body();
                    tvText.setText(verse.get("text").getAsString());
                    tvTransliteration.setText(verse.get("transliteration").getAsString());
                    tvTranslation.setText(verse.get("translation").getAsString());
                } else {
                    Toast.makeText(VerseDetailActivity.this, "Failed to load verse", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                Toast.makeText(VerseDetailActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("VerseDetail", t.getMessage());
            }
        });
    }
}
