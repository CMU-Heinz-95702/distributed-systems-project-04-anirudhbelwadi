package com.example.bhagavadgita.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import com.example.bhagavadgita.R;
import com.example.bhagavadgita.model.Verse;
import com.example.bhagavadgita.network.ApiClient;
import com.example.bhagavadgita.network.ApiService;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VerseListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private VerseListAdapter adapter;
    private int chapterId;

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verse_list);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        chapterId = getIntent().getIntExtra("chapter_number", -1);
        if (chapterId == -1) {
            Toast.makeText(this, "Invalid Chapter", Toast.LENGTH_SHORT).show();
            finish();
        }

        recyclerView = findViewById(R.id.verseRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        fetchVerses();
    }

    private void fetchVerses() {
        ApiService api = ApiClient.getApiService();
        api.getVerses(chapterId).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.body() != null) {
                    JsonArray jsonVerses = response.body().getAsJsonArray("verses");
                    Verse[] verses = new Gson().fromJson(jsonVerses, Verse[].class);
                    adapter = new VerseListAdapter(Arrays.asList(verses), VerseListActivity.this, chapterId);
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(VerseListActivity.this, "Failed to load verses", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(@NonNull Call<JsonObject> call, Throwable t) {
                Toast.makeText(VerseListActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("VerseList", Objects.requireNonNull(t.getMessage()));
            }
        });
    }
}
