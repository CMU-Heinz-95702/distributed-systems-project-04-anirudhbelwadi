package com.example.bhagavadgita.model;

public class Verse {
    private int verse_number;
    private String text;
    private String transliteration;
    private String translation;

    public int getVerse_number() { return verse_number; }
    public String getText() { return text; }
    public String getTransliteration() { return transliteration; }
    public String getTranslation() { return translation; }
}
