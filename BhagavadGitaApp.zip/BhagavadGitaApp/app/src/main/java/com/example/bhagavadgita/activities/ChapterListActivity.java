package com.example.bhagavadgita.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bhagavadgita.R;
import com.example.bhagavadgita.model.Chapter;
import com.example.bhagavadgita.network.ApiClient;
import com.example.bhagavadgita.network.ApiService;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChapterListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ChapterListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chapter_list);

        recyclerView = findViewById(R.id.chapterRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        fetchChapters();
    }

    private void fetchChapters() {
        ApiService api = ApiClient.getApiService();
        api.getChapters().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    JsonArray jsonChapters = response.body().getAsJsonArray("chapters");
                    Chapter[] chapters = new Gson().fromJson(jsonChapters, Chapter[].class);
                    adapter = new ChapterListAdapter(Arrays.asList(chapters), ChapterListActivity.this);
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(ChapterListActivity.this, "Failed to load chapters", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(ChapterListActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("API_ERROR", t.getMessage());
            }
        });
    }
}
