package com.example.bhagavadgita.activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bhagavadgita.R;
import com.example.bhagavadgita.model.Chapter;

import java.util.List;

public class ChapterListAdapter extends RecyclerView.Adapter<ChapterListAdapter.ChapterViewHolder> {

    private List<Chapter> chapters;
    private Context context;

    public ChapterListAdapter(List<Chapter> chapters, Context context) {
        this.chapters = chapters;
        this.context = context;
    }

    @NonNull
    @Override
    public ChapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_chapter, parent, false);
        return new ChapterViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ChapterViewHolder holder, int position) {
        Chapter chapter = chapters.get(position);
        holder.title.setText("Chapter " + chapter.getChapter_number() + ": " + chapter.getName());
        holder.meaning.setText(chapter.getMeaning());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ChapterDetailActivity.class);
            intent.putExtra("chapter_number", chapter.getChapter_number());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return chapters.size();
    }

    public static class ChapterViewHolder extends RecyclerView.ViewHolder {
        TextView title, meaning;
        public ChapterViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.chapterTitle);
            meaning = itemView.findViewById(R.id.chapterMeaning);
        }
    }
}
