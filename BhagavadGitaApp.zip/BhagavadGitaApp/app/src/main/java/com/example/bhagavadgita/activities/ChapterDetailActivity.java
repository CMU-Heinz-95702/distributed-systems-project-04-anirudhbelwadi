package com.example.bhagavadgita.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.example.bhagavadgita.R;
import com.example.bhagavadgita.network.ApiClient;
import com.example.bhagavadgita.network.ApiService;
import com.google.gson.JsonObject;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChapterDetailActivity extends AppCompatActivity {
    private TextView tvName, tvMeaning, tvSummary, tvVerseCount;
    private int chapterId;

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chapter_detail);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        tvName = findViewById(R.id.tvChapterName);
        tvMeaning = findViewById(R.id.tvChapterMeaning);
        tvSummary = findViewById(R.id.tvChapterSummary);
        tvVerseCount = findViewById(R.id.tvVerseCount);
        Button btnViewVerses = findViewById(R.id.btnViewVerses);

        chapterId = getIntent().getIntExtra("chapter_number", -1);
        if (chapterId == -1) {
            Toast.makeText(this, "Invalid Chapter", Toast.LENGTH_SHORT).show();
            finish();
        }

        fetchChapterDetail();

        btnViewVerses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ChapterDetailActivity.this, VerseListActivity.class);
                intent.putExtra("chapter_number", chapterId);
                startActivity(intent);
            }
        });
    }

    private void fetchChapterDetail() {
        ApiService api = ApiClient.getApiService();
        api.getChapterDetails(chapterId).enqueue(new Callback<JsonObject>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful() && response.body() != null) {
                    JsonObject chapter = response.body();
                    tvName.setText(chapter.get("name").getAsString());
                    tvMeaning.setText(chapter.get("meaning").getAsString());
                    tvSummary.setText(chapter.get("summary").getAsString());
                    tvVerseCount.setText("Verses: " + chapter.get("verses_count").getAsInt());
                } else {
                    Toast.makeText(ChapterDetailActivity.this, "Failed to load chapter details", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                Toast.makeText(ChapterDetailActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("ChapterDetail", Objects.requireNonNull(t.getMessage()));
            }
        });
    }
}
