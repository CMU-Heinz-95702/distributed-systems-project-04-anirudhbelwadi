package com.example.bhagavadgita.activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.bhagavadgita.R;
import com.example.bhagavadgita.model.Verse;
import java.util.List;

public class VerseListAdapter extends RecyclerView.Adapter<VerseListAdapter.VerseViewHolder> {

    private final List<Verse> verses;
    private final Context context;
    private final int chapterId;

    public VerseListAdapter(List<Verse> verses, Context context, int chapterId) {
        this.verses = verses;
        this.context = context;
        this.chapterId = chapterId;
    }

    @NonNull
    @Override
    public VerseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_verse, parent, false);
        return new VerseViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull VerseViewHolder holder, int position) {
        Verse verse = verses.get(position);
        holder.tvVerseNumber.setText("Verse " + verse.getVerse_number());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, VerseDetailActivity.class);
                intent.putExtra("chapter_number", chapterId);
                intent.putExtra("verse_number", verse.getVerse_number());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return verses.size();
    }

    public static class VerseViewHolder extends RecyclerView.ViewHolder {
        TextView tvVerseNumber;
        public VerseViewHolder(View itemView) {
            super(itemView);
            tvVerseNumber = itemView.findViewById(R.id.tvVerseNumber);
        }
    }
}
