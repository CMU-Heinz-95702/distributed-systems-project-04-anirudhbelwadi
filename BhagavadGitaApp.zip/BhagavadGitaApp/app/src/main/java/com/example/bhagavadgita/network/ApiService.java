package com.example.bhagavadgita.network;

import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiService {

    @GET("api/chapters")
    Call<JsonObject> getChapters();

    @GET("api/chapters/{chapterId}")
    Call<JsonObject> getChapterDetails(@Path("chapterId") int chapterId);

    @GET("api/chapters/{chapterId}/verses")
    Call<JsonObject> getVerses(@Path("chapterId") int chapterId);

    @GET("api/chapters/{chapterId}/verses/{verseId}")
    Call<JsonObject> getVerseDetails(@Path("chapterId") int chapterId, @Path("verseId") int verseId);
}
