package com.example.bhagavadgita.model;

public class Chapter {
    private int chapter_number;
    private String name;
    private String meaning;
    private int verses_count;

    public int getChapter_number() { return chapter_number; }
    public String getName() { return name; }
    public String getMeaning() { return meaning; }
    public int getVerses_count() { return verses_count; }
}
